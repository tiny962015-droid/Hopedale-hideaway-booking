import assert from 'node:assert/strict';
import { createApp, parseIcs } from '../netlify/lib/app.mjs';
import { fakeStore } from './fake-store.mjs';

let clock = new Date('2026-10-22T18:00:00-05:00').getTime();
let feedText = '';
let feedStatus = 200;
let fetched = [];
const fetchImpl = async (url) => {
  fetched.push(String(url));
  return new Response(feedText, { status: feedStatus });
};
const app = createApp({ store: fakeStore(), now: () => new Date(clock), env: {}, fetchImpl });

let n = 0;
async function call(method, path, { body, token } = {}) {
  const headers = {};
  if (token) headers.authorization = 'Bearer ' + token;
  if (body) headers['content-type'] = 'application/json';
  const res = await app.handle(new Request('http://x.test/api' + path, { method, headers, body: body ? JSON.stringify(body) : undefined }), { ip: '10.1.0.' + ++n });
  const ct = res.headers.get('content-type') || '';
  return { status: res.status, body: ct.includes('json') ? await res.json() : await res.text(), res };
}
let pass = 0;
const ok = (m) => { pass++; console.log('  ok  ' + m); };

const ics = (events) =>
  ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Airbnb Inc//Hosting Calendar 1.0//EN', 'CALSCALE:GREGORIAN',
    ...events.flatMap(([s, e, sum = 'Reserved']) => ['BEGIN:VEVENT', 'DTSTAMP:20261022T000000Z', `DTSTART;VALUE=DATE:${s}`, `DTEND;VALUE=DATE:${e}`, `UID:${s}-${e}@airbnb.com`, `SUMMARY:${sum}`, 'END:VEVENT']),
    'END:VCALENDAR', ''].join('\r\n');

// --- parser
const parsed = parseIcs('BEGIN:VCALENDAR\r\nBEGIN:VEVENT\r\nDTSTART;VALUE=DATE:20261201\r\nDTEND;VALUE=DATE:20261205\r\nSUMMARY:Reserv\r\n ed\r\nEND:VEVENT\r\nBEGIN:VEVENT\r\nDTSTART:20261210T150000Z\r\nEND:VEVENT\r\nBEGIN:VEVENT\r\nDTSTART;VALUE=DATE:garbage\r\nEND:VEVENT\r\nEND:VCALENDAR');
assert.equal(parsed.length, 2);
assert.deepEqual([parsed[0].start, parsed[0].end, parsed[0].summary], ['2026-12-01', '2026-12-05', 'Reserved']);
assert.deepEqual([parsed[1].start, parsed[1].end], ['2026-12-10', '2026-12-11']);
ok('calendar parser handles all-day dates, folded lines, missing end, junk');

const login = await call('POST', '/login', { body: { passcode: 'hopedale' } });
const token = login.body.token;

// --- feed security
let r = await call('GET', '/calendar.ics?unit=camp-main&key=whatever');
assert.equal(r.status, 404); ok('feed is hidden without the secret key');
r = await call('GET', '/admin/ical');
assert.equal(r.status, 401); ok('guests cannot read the sync settings');
r = await call('GET', '/admin/ical', { token });
assert.equal(r.status, 200);
const key = r.body.key;
assert.ok(key && key.length >= 20); ok('admin gets a secret feed key');
r = await call('GET', '/calendar.ics?unit=camp-main&key=' + key + 'x');
assert.equal(r.status, 404);
r = await call('GET', '/calendar.ics?unit=nope&key=' + key);
assert.equal(r.status, 404); ok('wrong key or unknown spot returns 404');

// --- a direct booking appears in the feed without personal details
await call('POST', '/book', { body: { unitId: 'camp-main', start: '2026-12-20', end: '2026-12-23', guest: 'Private Person', contact: 'private@example.com', ack: true } });
r = await call('GET', '/calendar.ics?unit=camp-main&key=' + key);
assert.equal(r.status, 200);
assert.match(r.res.headers.get('content-type'), /text\/calendar/);
assert.match(r.body, /DTSTART;VALUE=DATE:20261220/);
assert.match(r.body, /DTEND;VALUE=DATE:20261223/);
assert.doesNotMatch(r.body, /Private|example\.com/);
assert.match(r.body, /^BEGIN:VCALENDAR\r\n/);
ok('feed lists direct bookings as "Reserved" with no names or contacts');

// --- URL validation
for (const bad of ['http://www.airbnb.com/calendar/ical/1.ics', 'https://localhost/x.ics', 'https://127.0.0.1/x.ics', 'https://10.0.0.5/x.ics', 'javascript:alert(1)', 'not a url', 'https://[::1]/x.ics']) {
  r = await call('PUT', '/admin/ical', { token, body: { unitId: 'camp-main', url: bad } });
  assert.equal(r.status, 400, bad);
}
ok('only public https calendar links are accepted');

// --- import from Airbnb
feedText = ics([['20261201', '20261205'], ['20261222', '20261228'], ['20260101', '20260105']]);
r = await call('PUT', '/admin/ical', { token, body: { unitId: 'camp-main', url: 'webcal://www.airbnb.com/calendar/ical/123.ics?s=abc' } });
assert.equal(r.status, 200);
assert.equal(fetched.at(-1), 'https://www.airbnb.com/calendar/ical/123.ics?s=abc');
assert.equal(r.body.status['camp-main'].ok, true);
assert.equal(r.body.status['camp-main'].count, 2); ok('saving a link imports its upcoming reservations (past ones skipped)');

let s = await call('GET', '/state');
const ext = s.body.bookings.filter((b) => b.kind === 'external');
assert.equal(ext.length, 2);
for (const b of s.body.bookings) assert.deepEqual(Object.keys(b).sort(), ['end', 'kind', 'start', 'unitId']);
ok('guests see Airbnb dates as booked, nothing else');

r = await call('POST', '/book', { body: { unitId: 'camp-main', start: '2026-12-03', end: '2026-12-04', guest: 'Late Guest', contact: '555-1234', ack: true } });
assert.equal(r.status, 409); ok('Airbnb dates cannot be booked directly');

// Airbnb reservation that overlaps an existing direct booking is flagged, not deleted
s = await call('GET', '/state', { token });
assert.deepEqual(s.body.conflicts.length, 1);
const direct = s.body.bookings.find((b) => b.kind === 'booking' && b.start === '2026-12-20');
assert.equal(s.body.conflicts[0], direct.id); ok('overlap between a direct booking and Airbnb is flagged for the owner');

// imported dates are not echoed back to Airbnb
r = await call('GET', '/calendar.ics?unit=camp-main&key=' + key);
assert.doesNotMatch(r.body, /20261201/);
assert.match(r.body, /20261220/); ok('Airbnb reservations are not sent back to Airbnb');

// --- failures keep the old data
feedStatus = 500;
r = await call('POST', '/admin/ical/sync', { token });
assert.equal(r.body.status['camp-main'].ok, false);
assert.match(r.body.status['camp-main'].error, /500/);
s = await call('GET', '/state');
assert.equal(s.body.bookings.filter((b) => b.kind === 'external').length, 2);
ok('a failed sync keeps the last good Airbnb dates and reports the error');
feedStatus = 200; feedText = 'hello';
r = await call('POST', '/admin/ical/sync', { token });
assert.match(r.body.status['camp-main'].error, /not a calendar/); ok('a link that is not a calendar is reported');

// --- cancellations on Airbnb disappear after the next sync
feedText = ics([['20261222', '20261228']]);
await call('POST', '/admin/ical/sync', { token });
s = await call('GET', '/state');
assert.deepEqual(s.body.bookings.filter((b) => b.kind === 'external').map((b) => b.start), ['2026-12-22']);
ok('an Airbnb cancellation frees the dates on the next sync');

// --- the scheduled job path
feedText = ics([['20270105', '20270110']]);
const res = await app.syncAll();
assert.equal(res['camp-main'].count, 1);
s = await call('GET', '/state');
assert.deepEqual(s.body.bookings.filter((b) => b.kind === 'external').map((b) => b.start), ['2027-01-05']);
ok('scheduled sync updates the dates');

// --- Airbnb is re-checked right before a direct booking is accepted
feedStatus = 200;
feedText = ics([['20270105', '20270110'], ['20270201', '20270205']]);
clock += 60000;
const before = fetched.length;
r = await call('POST', '/book', { body: { unitId: 'camp-main', start: '2027-02-02', end: '2027-02-03', guest: 'Quick Guest', contact: '555-9999', ack: true } });
assert.equal(r.status, 409);
assert.ok(fetched.length > before); ok('a stay just booked on Airbnb is caught at booking time');

feedStatus = 500;
clock += 60000;
r = await call('POST', '/book', { body: { unitId: 'camp-main', start: '2027-03-01', end: '2027-03-03', guest: 'Quick Guest', contact: '555-9999', ack: true } });
assert.equal(r.status, 200); ok('if Airbnb cannot be reached, bookings still work with the last copy');
feedStatus = 200;

// --- disconnect
r = await call('PUT', '/admin/ical', { token, body: { unitId: 'camp-main', url: '' } });
assert.equal(r.status, 200);
s = await call('GET', '/state');
assert.equal(s.body.bookings.filter((b) => b.kind === 'external').length, 0);
assert.equal(r.body.urls['camp-main'], undefined); ok('disconnecting removes the imported dates');

// --- closed spot shows as closed to Airbnb
const camp = (await call('GET', '/state')).body.units.find((u) => u.id === 'camp-main');
await call('PUT', '/admin/unit', { token, body: { ...camp, status: 'closed', closedNote: 'Repairs' } });
r = await call('GET', '/calendar.ics?unit=camp-main&key=' + key);
assert.match(r.body, /SUMMARY:Closed/);
assert.match(r.body, /DTSTART;VALUE=DATE:20261022/); ok('a closed spot is sent to Airbnb as unavailable');

console.log(`\n${pass} calendar checks passed`);
