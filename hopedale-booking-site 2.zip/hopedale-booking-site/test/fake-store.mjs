// In-memory stand-in for a Netlify Blobs store, with the same conditional-write
// behaviour (onlyIfNew / onlyIfMatch return { modified }). The check and the
// write happen in one synchronous step, so it is atomic like the real thing.
export function fakeStore({ latency = 0 } = {}) {
  const m = new Map();
  let n = 0;
  const wait = () => (latency ? new Promise((r) => setTimeout(r, Math.random() * latency)) : Promise.resolve());
  return {
    async getWithMetadata(key) {
      await wait();
      const e = m.get(key);
      return e ? { data: e.data, etag: e.etag, metadata: e.metadata } : null;
    },
    async set(key, value, opts = {}) {
      await wait();
      const e = m.get(key);
      if (opts.onlyIfNew && e) return { modified: false };
      if (opts.onlyIfMatch !== undefined && (!e || e.etag !== opts.onlyIfMatch)) return { modified: false };
      const etag = `"${++n}"`;
      m.set(key, { data: value, etag, metadata: opts.metadata });
      return { modified: true, etag };
    },
    async delete(key) {
      m.delete(key);
    },
    _keys: () => [...m.keys()],
  };
}
