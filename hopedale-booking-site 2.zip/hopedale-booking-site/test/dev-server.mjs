// Local preview: serves ./site and runs the API in memory (nothing is saved after you stop it).
// Usage: node test/dev-server.mjs [port]
import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createApp } from '../netlify/lib/app.mjs';
import { fakeStore } from './fake-store.mjs';

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'site');
const app = createApp({ store: fakeStore(), env: process.env });
const types = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8' };

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://localhost');
    if (url.pathname.startsWith('/api/')) {
      const chunks = [];
      for await (const c of req) chunks.push(c);
      const body = chunks.length ? Buffer.concat(chunks) : undefined;
      const r = await app.handle(new Request(url, { method: req.method, headers: req.headers, body: ['GET', 'HEAD'].includes(req.method) ? undefined : body }), { ip: req.socket.remoteAddress });
      res.writeHead(r.status, Object.fromEntries(r.headers));
      res.end(Buffer.from(await r.arrayBuffer()));
      return;
    }
    const file = url.pathname === '/' ? '/index.html' : url.pathname;
    const full = path.join(root, path.normalize(file));
    if (!full.startsWith(root)) throw new Error('bad path');
    const data = await fs.readFile(full);
    res.writeHead(200, { 'content-type': types[path.extname(full)] || 'application/octet-stream' });
    res.end(data);
  } catch (e) {
    res.writeHead(404, { 'content-type': 'text/plain' });
    res.end('Not found');
  }
});

const port = Number(process.argv[2]) || 8888;
server.listen(port, () => console.log(`Preview at http://localhost:${port}`));
