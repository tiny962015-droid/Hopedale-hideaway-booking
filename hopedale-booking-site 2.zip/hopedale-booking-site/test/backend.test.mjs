import assert from 'node:assert/strict';
import { createApp } from '../netlify/lib/app.mjs';
import { fakeStore } from './fake-store.mjs';

let clock = new Date('2026-10-22T18:00:00-05:00').getTime();
const store = fakeStore({ latency: 8 });
const app = createApp({ store, now: () => new Date(clock), env: {} });

let ipN = 0;
async function call(method, path, { body, token, ip, raw } = {}) {
  const headers = {};
  if (token) headers.authorization = 'Bearer ' + token;
  if (body && !raw) headers['content-type'] = 'application/json';
  const req = new Request('http://x.test/api' + path, { method, headers, body: raw ? body : body ? JSON.stringify(body) : undefined });
  const res = await app.handle(req, { ip: ip || '10.0.0.' + ++ipN });
  const ct = res.headers.get('content-type') || '';
  return { status: res.status, body: ct.includes('json') ? await res.json() : await res.arrayBuffer(), res };
}

const good = (o = {}) => ({ unitId: 'camp-main', start: '2026-11-01', end: '2026-11-04', guest: 'Sam', contact: '555-0100', ack: true, ...o });
let pass = 0;
const ok = (name) => { pass++; console.log('  ok  ' + name); };

// --- public state starts with the seeded spots, no bookings
let s = await call('GET', '/state');
assert.equal(s.status, 200);
assert.equal(s.body.today, '2026-10-22');
assert.equal(s.body.admin, false);
assert.equal(s.body.units.length, 2);
assert.equal(s.body.bookings.length, 0);
ok('state loads with seeded spots');

// --- validation
let r = await call('POST', '/book', { body: good({ start: '2026-10-01', end: '2026-10-03' }) });
assert.equal(r.status, 400); ok('past dates rejected');
r = await call('POST', '/book', { body: good({ end: '2026-11-01' }) });
assert.equal(r.status, 400); ok('check-out must be after check-in');
r = await call('POST', '/book', { body: good({ ack: false }) });
assert.equal(r.status, 400); ok('payment note must be ticked');
r = await call('POST', '/book', { body: good({ contact: '' }) });
assert.equal(r.status, 400); ok('contact required');
r = await call('POST', '/book', { body: good({ unitId: 'slip-a1' }) });
assert.equal(r.status, 400); ok('slip needs a boat length');
r = await call('POST', '/book', { body: good({ unitId: 'slip-a1', boatFt: 30 }) });
assert.equal(r.status, 400); assert.match(r.body.message, /24 ft/); ok('boat longer than slip rejected');
r = await call('POST', '/book', { body: good({ block: true }) });
assert.equal(r.status, 401); ok('guests cannot block dates');
r = await call('POST', '/book', { body: good({ website: 'spam' }) });
assert.equal(r.status, 200);
s = await call('GET', '/state');
assert.equal(s.body.bookings.length, 0); ok('honeypot is dropped silently');

// --- the race: 25 people book overlapping dates at once
const attempts = await Promise.all(
  Array.from({ length: 25 }, (_, i) =>
    call('POST', '/book', { body: good({ guest: 'Guest ' + i, start: i % 2 ? '2026-12-01' : '2026-12-03', end: i % 2 ? '2026-12-05' : '2026-12-07' }) })
  )
);
const wins = attempts.filter((a) => a.status === 200);
const taken = attempts.filter((a) => a.status === 409 && a.body.error === 'taken');
assert.equal(wins.length, 1, 'exactly one overlapping booking should win, got ' + wins.length);
assert.equal(taken.length, 24);
ok('25 simultaneous overlapping bookings: exactly 1 succeeds, 24 told "taken"');

// --- same dates on different spots both work; back-to-back stays work
const [a, b] = await Promise.all([
  call('POST', '/book', { body: good({ start: '2027-01-10', end: '2027-01-12' }) }),
  call('POST', '/book', { body: good({ unitId: 'slip-a1', boatFt: 20, start: '2027-01-10', end: '2027-01-12' }) }),
]);
assert.equal(a.status, 200); assert.equal(b.status, 200); ok('same dates on different spots both succeed');
r = await call('POST', '/book', { body: good({ start: '2027-01-12', end: '2027-01-14' }) });
assert.equal(r.status, 200); ok('check-in on a check-out day is allowed');

// --- guests never see names or contacts
s = await call('GET', '/state');
assert.ok(s.body.bookings.length >= 4);
for (const bk of s.body.bookings) assert.deepEqual(Object.keys(bk).sort(), ['end', 'kind', 'start', 'unitId']);
ok('public view hides guest names and contacts');

// --- admin auth
r = await call('GET', '/state', {}); assert.equal(r.body.admin, false);
for (const [m, p] of [['PUT', '/admin/unit'], ['DELETE', '/admin/unit/camp-main'], ['PUT', '/admin/settings'], ['POST', '/admin/passcode'], ['POST', '/admin/photo']]) {
  r = await call(m, p, { body: {} }); assert.equal(r.status, 401, m + ' ' + p);
}
r = await call('GET', '/admin/anything', { token: 'v1.9999999999999.' + 'a'.repeat(64) }); assert.equal(r.status, 401);
ok('admin routes reject guests and forged tokens');
r = await call('POST', '/login', { body: { passcode: 'nope' } });
assert.equal(r.status, 401); ok('wrong passcode rejected');
r = await call('POST', '/login', { body: { passcode: '  HopeDale ' } });
assert.equal(r.status, 200);
let token = r.body.token;
assert.equal(r.body.defaultPasscode, true); ok('starting passcode works (any capitalization) and is flagged as default');

s = await call('GET', '/state', { token });
assert.equal(s.body.admin, true);
assert.equal(s.body.defaultPasscode, true);
assert.ok(s.body.bookings.some((x) => x.guest && x.contact && x.id)); ok('admin sees full booking details');

// --- login rate limit
const ip = '9.9.9.9';
let last;
for (let i = 0; i < 11; i++) last = await call('POST', '/login', { body: { passcode: 'bad' + i }, ip });
assert.equal(last.status, 429); ok('login is rate limited after repeated wrong tries');

// --- admin: edit, close, book blocked
const camp = s.body.units.find((u) => u.id === 'camp-main');
r = await call('PUT', '/admin/unit', { token, body: { ...camp, price: 450, priceUnit: 'night' } });
assert.equal(r.status, 200);
s = await call('GET', '/state');
assert.equal(s.body.units.length, 2, 'editing must not create a duplicate');
assert.equal(s.body.units.find((u) => u.id === 'camp-main').price, 450); ok('editing a spot updates it (no duplicate)');

r = await call('PUT', '/admin/unit', { token, body: { type: 'slip', name: 'B2', lengthFt: 40, price: 35, priceUnit: 'week' } });
assert.equal(r.status, 200);
const newId = r.body.unit.id;
assert.match(newId, /^b2-/); ok('creating a spot works');

r = await call('PUT', '/admin/unit', { token, body: { ...camp, status: 'closed', closedNote: 'Broken pipe' } });
assert.equal(r.status, 200);
r = await call('POST', '/book', { body: good({ start: '2027-03-01', end: '2027-03-03' }) });
assert.equal(r.status, 409); assert.equal(r.body.error, 'closed'); ok('closed spot cannot be booked');
await call('PUT', '/admin/unit', { token, body: { ...camp, price: 450 } });

r = await call('POST', '/book', { token, body: good({ block: true, guest: 'Repairs', contact: '', start: '2027-04-01', end: '2027-04-10', note: 'roof' }) });
assert.equal(r.status, 200);
r = await call('POST', '/book', { body: good({ start: '2027-04-05', end: '2027-04-06' }) });
assert.equal(r.status, 409); ok('admin can block dates and guests cannot book over them');

// --- photos
const jpeg = new Uint8Array(2000); jpeg.set([0xff, 0xd8, 0xff, 0xe0]);
r = await call('POST', '/admin/photo', { token, raw: true, body: new Uint8Array(2000) });
assert.equal(r.status, 400); ok('non-JPEG upload rejected');
r = await call('POST', '/admin/photo', { token, raw: true, body: jpeg });
assert.equal(r.status, 200);
const photoId = r.body.id;
r = await call('GET', '/photo/' + photoId);
assert.equal(r.status, 200); assert.equal(r.res.headers.get('content-type'), 'image/jpeg'); ok('photo upload and public download');
r = await call('PUT', '/admin/unit', { token, body: { ...camp, price: 450, photoId } });
assert.equal(r.status, 200);
r = await call('PUT', '/admin/unit', { token, body: { ...camp, price: 450, photoId: '' } });
r = await call('GET', '/photo/' + photoId);
assert.equal(r.status, 404); ok('replaced photo is cleaned up');

// --- delete rules
r = await call('DELETE', '/admin/unit/camp-main', { token });
assert.equal(r.status, 409); assert.equal(r.body.error, 'has_bookings'); ok('cannot delete a spot with upcoming bookings');
r = await call('DELETE', '/admin/unit/' + newId, { token });
assert.equal(r.status, 200); ok('can delete an empty spot');

// --- cancel a booking, then the dates open up
s = await call('GET', '/state', { token });
const victim = s.body.bookings.find((x) => x.unitId === 'camp-main' && x.start === '2027-01-10');
r = await call('POST', '/book', { body: good({ start: '2027-01-10', end: '2027-01-12' }) });
assert.equal(r.status, 409);
r = await call('DELETE', '/admin/booking/' + victim.id, { token });
assert.equal(r.status, 200);
r = await call('POST', '/book', { body: good({ start: '2027-01-10', end: '2027-01-12' }) });
assert.equal(r.status, 200); ok('cancelled dates can be booked again');

// --- settings
r = await call('PUT', '/admin/settings', { token, body: { name: 'Hopedale Hideaway', policy: 'Cash only. Bring exact change.' } });
assert.equal(r.status, 200);
s = await call('GET', '/state');
assert.equal(s.body.settings.policy, 'Cash only. Bring exact change.'); ok('payment note can be changed');

// --- passcode change
r = await call('POST', '/admin/passcode', { token, body: { old: 'wrong', new: 'lakehouse1' } });
assert.equal(r.status, 403);
r = await call('POST', '/admin/passcode', { token, body: { old: 'hopedale', new: 'abc' } });
assert.equal(r.status, 400);
r = await call('POST', '/admin/passcode', { token, body: { old: 'hopedale', new: 'LakeHouse1' } });
assert.equal(r.status, 200);
const token2 = r.body.token;
r = await call('GET', '/state', { token });
assert.equal(r.body.admin, false, 'old session must end');
r = await call('GET', '/state', { token: token2 });
assert.equal(r.body.admin, true); assert.equal(r.body.defaultPasscode, false);
r = await call('POST', '/login', { body: { passcode: 'hopedale' } });
assert.equal(r.status, 401);
r = await call('POST', '/login', { body: { passcode: 'lakehouse1' } });
assert.equal(r.status, 200); ok('passcode change: old passcode and old sessions stop working');

// --- sessions expire
clock += 13 * 3600 * 1000;
r = await call('GET', '/state', { token: token2 });
assert.equal(r.body.admin, false); ok('admin session expires after 12 hours');

// --- fail closed when storage cannot do conditional writes
const weak = fakeStore();
const origSet = weak.set;
weak.set = async (k, v, o = {}) => { await origSet(k, v, {}); };   // ignores conditions, returns nothing
const app2 = createApp({ store: weak, env: {}, now: () => new Date(clock) });
const rr = await app2.handle(new Request('http://x.test/api/book', { method: 'POST', body: JSON.stringify(good({ start: '2027-06-01', end: '2027-06-02' })) }), { ip: '1.1.1.1' });
assert.equal(rr.status, 500); ok('refuses bookings if storage cannot do safe writes');

console.log(`\n${pass} checks passed`);
