import { getStore } from '@netlify/blobs';
import { createApp } from '../lib/app.mjs';

let app;

export default async (req, context) => {
  app ||= createApp({
    store: getStore({ name: 'camp', consistency: 'strong' }),
    env: process.env,
  });
  const ip = (context && context.ip) || req.headers.get('x-nf-client-connection-ip') || 'unknown';
  return app.handle(req, { ip });
};

export const config = { path: '/api/*' };
