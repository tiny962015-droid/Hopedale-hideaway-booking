// Runs every minute: pulls each spot's Airbnb calendar and blocks those dates here.
import { getStore } from '@netlify/blobs';
import { createApp } from '../lib/app.mjs';

export default async () => {
  const app = createApp({ store: getStore({ name: 'camp', consistency: 'strong' }), env: process.env });
  const results = await app.syncAll();
  console.log('calendar sync', JSON.stringify(results));
};

export const config = { schedule: '* * * * *' };
