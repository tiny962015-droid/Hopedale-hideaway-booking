# Hopedale Hideaway Booking

A public booking site for the camp and boat slips. Guests book and see availability. You sign in with a passcode to manage spots, prices, photos, closures and bookings. Airbnb calendars can sync both ways.

Everything runs on Netlify. There is no separate database to set up.

## Put it online

Use one of these two ways. Both give you a free address like `yourname.netlify.app`.

### A. From GitHub (easiest to keep updated)
1. Create a new GitHub repository and upload everything in this folder.
2. In Netlify choose **Add new site > Import an existing project**, pick the repository, and leave the build command empty. The settings come from `netlify.toml`.
3. Click **Deploy**. Netlify installs what it needs and starts the site and the once-a-minute Airbnb check.

### B. From your computer
Needs Node 20 or newer.
1. In this folder run `npm install`.
2. Run `npx netlify login`, then `npx netlify deploy --prod` and follow the prompts to create the site.

Netlify's drag-and-drop upload may not include the backend, so use A or B.

## First five minutes
1. Pick a nicer address under **Site configuration > Change site name**.
2. Open the site, tap **Admin sign in**, and enter `hopedale`.
3. **Change the passcode right away** (Manage > Admin passcode). A warning stays on screen until you do.
4. Add your photos and prices (Manage), and the rest of the boat slips.

## Airbnb sync
Do this once per spot that is also listed on Airbnb. Menu names in Airbnb can differ slightly.
1. In Manage > Airbnb calendar sync, copy the link under "Give this link to Airbnb".
2. In Airbnb, open that listing's calendar settings, find **Connect calendars**, choose **Import calendar** and paste the link.
3. In the same Airbnb screen choose **Export calendar**, copy Airbnb's link, and paste it into "Airbnb link for this spot" here. Press **Save**.

This site checks Airbnb every minute, and again just before it accepts any booking for a linked spot (or press **Sync now**). Airbnb reads this site's link on its own schedule, usually every few hours, so a booking made here can take that long to close the dates on Airbnb. If two bookings do overlap, the booking is flagged in Manage.

Only dates are shared. Guest names and contact details never leave this site.

## Optional settings
Set these in Netlify under **Site configuration > Environment variables**.
- `ADMIN_PASSCODE`: the starting passcode (default `hopedale`). Ignored once you change it in Manage.
- `CAMP_TIMEZONE`: default `America/Chicago`. Decides what "today" means.
- `SESSION_SECRET`: optional long random text for admin sign-in.

## Things to know
- Guests pay in cash. The payment note is shown at the top and ticked before each booking. Change the wording in Manage.
- Guests give a name and phone or email. Online stays are limited to 180 nights.
- The site refuses bookings and shows an error if its storage cannot guarantee no double booking. If you ever see "Storage is not set up for safe bookings", update the `@netlify/blobs` package.
- Netlify's scheduler cannot run more often than once a minute. If Netlify refuses that schedule when you deploy, change `schedule` in `netlify/functions/sync.mjs` to `*/5 * * * *`. The check before each booking still applies.
- Admin sign-in locks for 15 minutes after 10 wrong tries from one address.

## For developers
- `npm test` runs the backend checks (including 25 people booking the same dates at once).
- `npm run dev` previews the site at http://localhost:8888 with throwaway in-memory data.
- `site/` is the page. `netlify/lib/app.mjs` is the backend. `netlify/functions/api.mjs` serves it and `netlify/functions/sync.mjs` runs the once-a-minute Airbnb check.
