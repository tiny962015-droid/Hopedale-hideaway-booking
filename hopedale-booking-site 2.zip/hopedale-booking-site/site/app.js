(function () {
  'use strict';
  var $ = function (s) { return document.querySelector(s); };

  function el(tag, props) {
    var e = document.createElement(tag), k, v, kids = [].slice.call(arguments, 2);
    props = props || {};
    for (k in props) {
      v = props[k];
      if (k === 'class') e.className = v;
      else if (k === 'text') e.textContent = v;
      else if (k.slice(0, 2) === 'on') e.addEventListener(k.slice(2), v);
      else if (v === true) e.setAttribute(k, '');
      else if (v !== false && v != null) e.setAttribute(k, v);
    }
    kids.flat(3).forEach(function (c) { if (c == null || c === false) return; e.append(c.nodeType ? c : document.createTextNode(c)); });
    return e;
  }

  var pad = function (n) { return String(n).padStart(2, '0'); };
  var iso = function (d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); };
  var parse = function (s) { var p = s.split('-').map(Number); return new Date(p[0], p[1] - 1, p[2]); };
  var addDays = function (s, n) { var d = parse(s); d.setDate(d.getDate() + n); return iso(d); };
  var nightsBetween = function (a, b) { return Math.round((parse(b) - parse(a)) / 864e5); };
  var fmtD = function (s) { return parse(s).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }); };
  var fmtDW = function (s) { return parse(s).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' }); };
  var money = function (n) { return '$' + Number(n).toLocaleString('en-US', { maximumFractionDigits: 2 }); };
  var PERIOD = { night: 1, week: 7, month: 30 };
  var periodOf = function (u) { return PERIOD[u.priceUnit] ? u.priceUnit : 'night'; };
  var totalFor = function (u, n) { return u.price * n / PERIOD[periodOf(u)]; };

  var today = iso(new Date());   // replaced by the server's date after the first load
  var DEFAULT_POLICY = 'Cash payments only. If you do not bring cash, your stay will be canceled.';

  var S = {
    units: [], bookings: [], settings: { name: '', policy: DEFAULT_POLICY },
    admin: false, defaultPw: false, token: null, tab: 'book', type: 'all',
    start: '', end: '', boat: '', calStart: today, loaded: false, loadErr: false, last: '',
    settingsDirty: false, ical: null, conflicts: []
  };
  try { S.token = sessionStorage.getItem('campAdmin'); } catch (e) {}
  function saveToken(t) {
    S.token = t || null;
    try { if (t) sessionStorage.setItem('campAdmin', t); else sessionStorage.removeItem('campAdmin'); } catch (e) {}
  }

  var WAVES = '<svg width="64" height="64" viewBox="0 0 64 64" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" aria-hidden="true"><path d="M6 26c6-6 12-6 18 0s12 6 18 0 12-6 16 0"/><path d="M6 40c6-6 12-6 18 0s12 6 18 0 12-6 16 0"/><path d="M6 54c6-6 12-6 18 0s12 6 18 0 12-6 16 0"/></svg>';
  var WAVES_S = '<svg width="26" height="26" viewBox="0 0 64 64" fill="none" stroke="currentColor" stroke-width="5" stroke-linecap="round" aria-hidden="true"><path d="M6 26c6-6 12-6 18 0s12 6 18 0 12-6 16 0"/><path d="M6 46c6-6 12-6 18 0s12 6 18 0 12-6 16 0"/></svg>';
  function svgNode(html) { var d = document.createElement('div'); d.innerHTML = html; return d.firstChild; }

  function toast(msg) {
    var t = $('#toast'); t.textContent = msg; t.hidden = false;
    clearTimeout(toast._t); toast._t = setTimeout(function () { t.hidden = true; }, 4500);
  }

  /* ---------- talking to the server ---------- */
  async function api(path, opts) {
    opts = opts || {};
    var headers = Object.assign({}, opts.headers || {});
    if (S.token) headers.Authorization = 'Bearer ' + S.token;
    var body = opts.body;
    if (body !== undefined && !opts.raw) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(body); }
    var r = await fetch('/api' + path, { method: opts.method || 'GET', headers: headers, body: body, cache: 'no-store' });
    var data = null;
    try { data = await r.json(); } catch (e) {}
    if (!r.ok) {
      var err = new Error((data && data.message) || 'Something went wrong. Try again.');
      err.status = r.status; err.data = data || {};
      if (r.status === 401 && S.token && path.indexOf('/login') !== 0) {
        saveToken(null); S.admin = false; renderAll();
        toast('Admin session ended. Sign in again.');
      }
      throw err;
    }
    return data;
  }

  async function refresh() {
    try {
      var d = await api('/state');
      S.loadErr = false;
      if (S.token && !d.admin) saveToken(null);
      var sig = JSON.stringify(d);
      if (sig === S.last && S.loaded) { if (S.admin && !S.ical) loadIcal(); renderChrome(); return; }
      S.last = sig;
      today = d.today;
      if (!S.calStart || S.calStart < today) S.calStart = today;
      S.units = d.units; S.bookings = d.bookings; S.settings = d.settings;
      S.admin = !!d.admin; S.defaultPw = !!d.defaultPasscode; S.loaded = true;
      S.conflicts = d.conflicts || [];
      if (!S.admin) S.ical = null; else if (!S.ical) loadIcal();
      $('#fStart').min = today; $('#fEnd').min = today;
      renderAll();
    } catch (e) {
      S.loadErr = true; S.loaded = S.loaded; renderChrome();
      if (!S.loaded) renderCards();
    }
  }

  /* ---------- data helpers ---------- */
  function sortedUnits() {
    return S.units.slice().sort(function (a, b) {
      if (a.type !== b.type) return a.type === 'camp' ? -1 : 1;
      return String(a.name).localeCompare(String(b.name), undefined, { numeric: true });
    });
  }
  var overlap = function (a, b) { return a.start < b.end && b.start < a.end; };
  var bookingsFor = function (uid) { return S.bookings.filter(function (b) { return b.unitId === uid; }); };
  function statusOf(u, s, e) {
    if (u.status === 'closed') return 'closed';
    var r = (s && e && e > s) ? { start: s, end: e } : { start: today, end: addDays(today, 1) };
    return bookingsFor(u.id).some(function (b) { return overlap(b, r); }) ? 'booked' : 'free';
  }
  var typeLabel = function (u) { return u.type === 'slip' ? 'Boat slip' : 'Camp'; };
  var photoUrl = function (id) { return '/api/photo/' + id; };

  /* ---------- modal ---------- */
  var modalRefresh = null;
  function closeModal() { $('#modalRoot').replaceChildren(); modalRefresh = null; document.removeEventListener('keydown', escClose); }
  function escClose(e) { if (e.key === 'Escape') closeModal(); }
  function openModal(title, body) {
    var root = $('#modalRoot'); root.replaceChildren();
    var dlg = el('div', { class: 'dialog', role: 'dialog', 'aria-modal': 'true', 'aria-label': title }, el('h2', { text: title }), body);
    var scrim = el('div', { class: 'scrim', onmousedown: function (e) { if (e.target === scrim) closeModal(); } }, dlg);
    root.append(scrim);
    document.addEventListener('keydown', escClose);
    var first = dlg.querySelector('input:not([type=hidden]):not(.hp input),select,textarea,button');
    if (first) first.focus();
  }

  /* ---------- book dialog ---------- */
  function openBook(unit, startDate) {
    var isSlip = unit.type === 'slip';
    var f = { name: '', contact: '', start: startDate || S.start || '', end: startDate ? addDays(startDate, 1) : (S.end || ''), boat: S.boat || '', block: false, note: '', ack: false };
    if (f.start && (!f.end || f.end <= f.start)) f.end = addDays(f.start, 1);
    var pending = false;
    var nameL = el('label', { for: 'bk-name', text: 'Your name' });
    var nameI = el('input', { id: 'bk-name', type: 'text', maxlength: '60', required: true, autocomplete: 'name', oninput: function () { f.name = this.value; refresh2(); } });
    var conI = el('input', { id: 'bk-contact', type: 'text', maxlength: '80', autocomplete: 'tel', placeholder: 'Phone number or email', oninput: function () { f.contact = this.value; refresh2(); } });
    var stI = el('input', { id: 'bk-start', type: 'date', min: today, value: f.start, oninput: function () {
      f.start = this.value; if (f.start && (!f.end || f.end <= f.start)) { f.end = addDays(f.start, 1); enI.value = f.end; } refresh2(); } });
    var enI = el('input', { id: 'bk-end', type: 'date', min: today, value: f.end, oninput: function () { f.end = this.value; refresh2(); } });
    var boatI = el('input', { id: 'bk-boat', type: 'number', min: '1', max: '200', inputmode: 'numeric', value: f.boat, oninput: function () { f.boat = this.value; refresh2(); } });
    var noteI = el('textarea', { id: 'bk-note', maxlength: '200', oninput: function () { f.note = this.value; refresh2(); } });
    var hp = el('input', { type: 'text', name: 'website', tabindex: '-1', autocomplete: 'off', 'aria-hidden': 'true' });
    var blockC = el('input', { type: 'checkbox', id: 'bk-block', onchange: function () {
      f.block = this.checked; ackRow.hidden = f.block; conField.hidden = f.block; nameL.textContent = f.block ? 'Reason for blocking' : 'Your name'; refresh2(); } });
    var ackC = el('input', { type: 'checkbox', id: 'bk-ack', onchange: function () { f.ack = this.checked; refresh2(); } });
    var ackRow = el('label', { class: 'check', for: 'bk-ack' }, ackC, el('span', { text: S.settings.policy + ' I understand.' }));
    var conField = el('div', { class: 'field' }, el('label', { for: 'bk-contact', text: 'Contact' }), conI);
    var sum = el('p', { class: 'summary', role: 'status' });
    var sub = el('button', { class: 'btn primary', type: 'submit', text: 'Confirm booking' });

    function setLen(days) {
      if (!f.start) { f.start = today; stI.value = today; }
      f.end = addDays(f.start, days); enI.value = f.end; refresh2();
    }
    function validate() {
      if (!f.start || !f.end) return { err: 'Choose check-in and check-out dates.' };
      if (f.end <= f.start) return { err: 'Check-out has to be after check-in.' };
      if (f.start < today) return { err: 'Check-in cannot be in the past.' };
      if (unit.status === 'closed') return { err: unit.name + ' is closed right now.' };
      var hit = bookingsFor(unit.id).find(function (b) { return overlap(b, f); });
      if (hit) return { err: 'Taken from ' + fmtD(hit.start) + ' to ' + fmtD(hit.end) + '. Pick other dates.' };
      if (!f.name.trim()) return { err: f.block ? 'Add a short reason.' : 'Add your name.', soft: true };
      if (!f.block && f.contact.trim().length < 3) return { err: 'Add a phone number or email.', soft: true };
      if (!f.block && isSlip) {
        if (!f.boat) return { err: 'Enter your boat length.', soft: true };
        if (unit.lengthFt && Number(f.boat) > unit.lengthFt) return { err: 'This slip fits boats up to ' + unit.lengthFt + ' ft.' };
      }
      if (!f.block && !f.ack) return { err: 'Tick the box to confirm the payment note.', soft: true };
      return { ok: true };
    }
    function refresh2() {
      var v = validate(), n = f.start && f.end && f.end > f.start ? nightsBetween(f.start, f.end) : 0;
      if (v.err && !v.soft) { sum.className = 'summary bad'; sum.textContent = v.err; }
      else {
        sum.className = 'summary';
        var per = periodOf(unit);
        var tot = n && unit.price != null ? ' · ' + money(totalFor(unit, n)) + ' total' + (per === 'night' ? '' : ' (prorated from the ' + per + 'ly rate)') : '';
        sum.textContent = (n ? n + (n === 1 ? ' night' : ' nights') + tot : 'Pick your dates') + (v.err ? ' · ' + v.err : '');
      }
      sub.disabled = pending || !!(v.err && !v.soft);
      sub.textContent = f.block ? 'Block dates' : 'Confirm booking';
    }

    var form = el('form', { style: 'display:grid;gap:14px', novalidate: true, onsubmit: async function (ev) {
      ev.preventDefault(); if (pending) return;
      var v = validate(); if (v.err) { refresh2(); return; }
      pending = true; sub.disabled = true; sub.textContent = 'Booking';
      try {
        await api('/book', { method: 'POST', body: {
          unitId: unit.id, start: f.start, end: f.end, guest: f.name.trim(), contact: f.contact.trim(),
          boatFt: isSlip && f.boat ? Number(f.boat) : null, block: f.block, ack: f.ack, note: f.note.trim(), website: hp.value } });
        closeModal();
        toast((f.block ? 'Blocked ' : 'Booked ') + unit.name + ', ' + fmtD(f.start) + ' to ' + fmtD(f.end));
        refresh();
      } catch (e) {
        pending = false; sub.disabled = false; sub.textContent = f.block ? 'Block dates' : 'Confirm booking';
        sum.className = 'summary bad';
        sum.textContent = e.status ? e.message : 'Could not reach the server. Check your connection and try again.';
        if (e.status === 409) refresh();
      }
    } },
      el('div', { class: 'field' }, nameL, nameI),
      conField,
      el('div', { class: 'two' }, el('div', { class: 'field' }, el('label', { for: 'bk-start', text: 'Check-in' }), stI), el('div', { class: 'field' }, el('label', { for: 'bk-end', text: 'Check-out' }), enI)),
      el('div', { class: 'dactions', style: 'justify-content:flex-start' }, el('span', { style: 'font-size:12px;color:var(--muted);align-self:center', text: 'Quick stay' }),
        el('button', { class: 'btn small', type: 'button', text: '1 week', onclick: function () { setLen(7); } }),
        el('button', { class: 'btn small', type: 'button', text: '2 weeks', onclick: function () { setLen(14); } }),
        el('button', { class: 'btn small', type: 'button', text: '1 month', onclick: function () { setLen(30); } })),
      isSlip ? el('div', { class: 'field' }, el('label', { for: 'bk-boat', text: 'Boat length (ft)' }), boatI) : null,
      S.admin ? el('label', { class: 'check', for: 'bk-block' }, blockC, el('span', { text: 'Block these dates (repairs, personal use). No guest is booked.' })) : null,
      S.admin ? el('div', { class: 'field' }, el('label', { for: 'bk-note', text: 'Note (admin only)' }), noteI) : null,
      el('div', { class: 'hp' }, hp),
      ackRow,
      sum,
      el('div', { class: 'dactions' }, el('button', { class: 'btn', type: 'button', text: 'Cancel', onclick: closeModal }), sub)
    );
    modalRefresh = refresh2;
    openModal((unit.name ? 'Book ' : 'Book ') + unit.name, form);
    refresh2();
  }

  /* ---------- admin: close, reopen, save ---------- */
  function unitBody(u, patch) { return Object.assign({}, u, patch || {}); }
  async function saveUnit(body, okMsg) {
    try { await api('/admin/unit', { method: 'PUT', body: body }); toast(okMsg); await refresh(); return true; }
    catch (e) { toast(e.message); return false; }
  }
  function openClose(unit) {
    var note = el('input', { id: 'cl-note', type: 'text', maxlength: '100', placeholder: 'e.g. Broken ladder, water line repair' });
    var form = el('form', { style: 'display:grid;gap:14px', onsubmit: async function (ev) {
      ev.preventDefault();
      if (await saveUnit(unitBody(unit, { status: 'closed', closedNote: note.value.trim() }), unit.name + ' is closed to bookings')) closeModal();
    } },
      el('p', { class: 'desc', text: 'Guests will see this as closed and cannot book it until you reopen it. Existing bookings stay in the calendar.' }),
      el('div', { class: 'field' }, el('label', { for: 'cl-note', text: 'Reason (shown to guests)' }), note),
      el('div', { class: 'dactions' }, el('button', { class: 'btn', type: 'button', text: 'Cancel', onclick: closeModal }), el('button', { class: 'btn primary', type: 'submit', text: 'Close ' + unit.name })));
    openModal('Close ' + unit.name + '?', form);
  }
  function reopen(unit) { saveUnit(unitBody(unit, { status: 'open', closedNote: '' }), unit.name + ' is open for booking'); }

  /* ---------- photos ---------- */
  async function shrink(file) {
    var bmp = await createImageBitmap(file);
    var k = Math.min(1, 1400 / Math.max(bmp.width, bmp.height));
    var c = document.createElement('canvas'); c.width = Math.round(bmp.width * k); c.height = Math.round(bmp.height * k);
    c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
    return await new Promise(function (r) { c.toBlob(r, 'image/jpeg', 0.82); });
  }

  /* ---------- unit editor ---------- */
  function openEdit(unit) {
    var isNew = !unit;
    var d = unit ? { type: unit.type, name: unit.name, lengthFt: unit.lengthFt || '', sleeps: unit.sleeps || '', price: unit.price == null ? '' : unit.price, priceUnit: periodOf(unit), desc: unit.desc || '', photoId: unit.photoId || '', status: unit.status || 'open', closedNote: unit.closedNote || '' }
      : { type: 'slip', name: '', lengthFt: '', sleeps: '', price: '', priceUnit: 'night', desc: '', photoId: '', status: 'open', closedNote: '' };
    var typeS = el('select', { id: 'ed-type', onchange: function () { d.type = this.value; sync(); } }, el('option', { value: 'camp', text: 'Camp' }), el('option', { value: 'slip', text: 'Boat slip' })); typeS.value = d.type;
    var nameI = el('input', { id: 'ed-name', type: 'text', maxlength: '50', required: true, value: d.name, oninput: function () { d.name = this.value; } });
    var lenI = el('input', { id: 'ed-len', type: 'number', min: '1', max: '300', inputmode: 'numeric', value: d.lengthFt, oninput: function () { d.lengthFt = this.value; } });
    var sleI = el('input', { id: 'ed-sleeps', type: 'number', min: '1', max: '100', inputmode: 'numeric', value: d.sleeps, oninput: function () { d.sleeps = this.value; } });
    var priI = el('input', { id: 'ed-price', type: 'number', min: '0', step: '0.01', inputmode: 'decimal', value: d.price, oninput: function () { d.price = this.value; } });
    var unitS = el('select', { id: 'ed-unit', onchange: function () { d.priceUnit = this.value; } }, el('option', { value: 'night', text: 'Night' }), el('option', { value: 'week', text: 'Week' }), el('option', { value: 'month', text: 'Month' })); unitS.value = d.priceUnit;
    var desI = el('textarea', { id: 'ed-desc', maxlength: '300', oninput: function () { d.desc = this.value; } }); desI.value = d.desc;
    var lenF = el('div', { class: 'field' }, el('label', { for: 'ed-len', text: 'Max boat length (ft)' }), lenI);
    var sleF = el('div', { class: 'field' }, el('label', { for: 'ed-sleeps', text: 'Sleeps' }), sleI);
    var clC = el('input', { type: 'checkbox', id: 'ed-closed', onchange: function () { d.status = this.checked ? 'closed' : 'open'; sync(); } }); clC.checked = d.status === 'closed';
    var clN = el('input', { id: 'ed-cnote', type: 'text', maxlength: '100', value: d.closedNote, placeholder: 'Reason shown to guests', oninput: function () { d.closedNote = this.value; } });
    var clF = el('div', { class: 'field' }, el('label', { for: 'ed-cnote', text: 'Closed reason' }), clN);
    var thumb = el('div', { class: 'thumb' });
    var msg = el('p', { class: 'note', role: 'status' });
    var fileI = el('input', { id: 'ed-photo', type: 'file', accept: 'image/*', style: 'max-width:100%', onchange: async function () {
      var file = this.files && this.files[0]; if (!file) return;
      msg.textContent = 'Uploading photo';
      try {
        var blob = await shrink(file);
        var up = await api('/admin/photo', { method: 'POST', raw: true, headers: { 'Content-Type': 'image/jpeg' }, body: blob });
        d.photoId = up.id; msg.textContent = ''; paintThumb();
      } catch (e) { msg.textContent = e.status ? e.message : 'Photo upload failed. Try a smaller image.'; }
    } });
    var rmB = el('button', { class: 'btn small', type: 'button', text: 'Remove photo', onclick: function () { d.photoId = ''; fileI.value = ''; paintThumb(); } });
    var photoF = el('div', { class: 'field' }, el('span', { class: 'lab', text: 'Photo' }),
      el('div', { class: 'photoedit' }, thumb, el('div', { style: 'display:grid;gap:8px;min-width:0' }, fileI, rmB)), msg);
    function paintThumb() {
      thumb.replaceChildren();
      if (d.photoId) thumb.append(el('img', { src: photoUrl(d.photoId), alt: '' })); else thumb.append(svgNode(WAVES_S));
      rmB.hidden = !d.photoId;
    }
    function sync() { lenF.hidden = d.type !== 'slip'; sleF.hidden = d.type !== 'camp'; clF.hidden = d.status !== 'closed'; }
    var form = el('form', { style: 'display:grid;gap:14px', onsubmit: async function (ev) {
      ev.preventDefault();
      if (!d.name.trim()) { nameI.focus(); return; }
      var body = { type: d.type, name: d.name.trim(), price: d.price === '' ? null : Number(d.price), priceUnit: d.priceUnit, desc: d.desc.trim(), photoId: d.photoId || '', status: d.status, closedNote: d.status === 'closed' ? d.closedNote.trim() : '' };
      if (d.type === 'slip') body.lengthFt = d.lengthFt === '' ? null : Number(d.lengthFt); else body.sleeps = d.sleeps === '' ? null : Number(d.sleeps);
      if (!isNew) body.id = unit.id;
      if (await saveUnit(body, (isNew ? 'Added ' : 'Saved ') + body.name)) closeModal();
    } },
      el('div', { class: 'two' }, el('div', { class: 'field' }, el('label', { for: 'ed-type', text: 'Type' }), typeS), el('div', { class: 'field' }, el('label', { for: 'ed-name', text: 'Name' }), nameI)),
      el('div', { class: 'two' }, lenF, sleF),
      el('div', { class: 'two' }, el('div', { class: 'field' }, el('label', { for: 'ed-price', text: 'Price ($)' }), priI), el('div', { class: 'field' }, el('label', { for: 'ed-unit', text: 'Charged per' }), unitS)),
      el('div', { class: 'field' }, el('label', { for: 'ed-desc', text: 'Description' }), desI),
      photoF,
      el('label', { class: 'check', for: 'ed-closed' }, clC, el('span', { text: 'Closed (broken or unavailable). Guests cannot book it.' })),
      clF,
      el('div', { class: 'dactions' }, el('button', { class: 'btn', type: 'button', text: 'Cancel', onclick: closeModal }), el('button', { class: 'btn primary', type: 'submit', text: isNew ? 'Add' : 'Save' }))
    );
    openModal(isNew ? 'Add a camp or slip' : 'Edit ' + unit.name, form);
    sync(); paintThumb();
  }

  /* ---------- Book tab ---------- */
  function renderCards() {
    var box = $('#cards'); box.replaceChildren();
    var all = sortedUnits(), boat = Number(S.boat) || 0;
    var list = all.filter(function (u) { return S.type === 'all' || u.type === S.type; });
    if (boat) list = list.filter(function (u) { return u.type !== 'slip' || !u.lengthFt || u.lengthFt >= boat; });
    var ranged = S.start && S.end && S.end > S.start;
    $('#count').textContent = all.length ? (list.length + ' of ' + all.length + ' shown' + (ranged ? ' · availability for ' + fmtD(S.start) + ' to ' + fmtD(S.end) : ' · availability shown for tonight')) : '';
    if (!S.loaded) { box.style.display = 'block'; box.append(el('p', { class: 'count', text: S.loadErr ? 'Could not load availability. Retrying.' : 'Loading' })); return; }
    if (!all.length) {
      box.style.display = 'block';
      box.append(el('div', { class: 'empty' }, el('h3', { text: 'Nothing to book yet' }),
        el('p', { text: S.admin ? 'Add your camp and each boat slip with a price, length and photo.' : 'Check back soon.' }),
        S.admin ? el('button', { class: 'btn primary', type: 'button', text: 'Add the first one', onclick: function () { setTab('manage'); openEdit(null); } }) : null));
      return;
    }
    if (!list.length) { box.style.display = 'block'; box.append(el('div', { class: 'empty' }, el('h3', { text: 'No match' }), el('p', { text: 'Nothing fits that boat length or type. Clear the filters to see everything.' }))); return; }
    box.style.display = '';
    list.forEach(function (u) {
      var st = statusOf(u, S.start, S.end);
      var label = st === 'closed' ? 'Closed' : st === 'booked' ? (ranged ? 'Booked for these dates' : 'Taken tonight') : (ranged ? 'Open for these dates' : 'Open tonight');
      var media = el('div', { class: 'media' });
      if (u.photoId) media.append(el('img', { src: photoUrl(u.photoId), alt: u.name + ' photo', loading: 'lazy' }));
      else { var ph = el('div', { class: 'ph' }); ph.append(svgNode(WAVES)); media.append(ph); }
      media.append(el('span', { class: 'chip ' + (st === 'free' ? 'ok' : st), text: label }));
      var specs = el('p', { class: 'specs' }, el('span', { text: typeLabel(u) }),
        u.type === 'slip' && u.lengthFt ? el('span', {}, 'Fits up to ', el('b', { text: u.lengthFt + ' ft' })) : null,
        u.type === 'camp' && u.sleeps ? el('span', {}, 'Sleeps ', el('b', { text: u.sleeps })) : null);
      var acts = el('div', { class: 'cactions' },
        el('button', { class: 'btn primary', type: 'button', text: st === 'closed' ? 'Closed' : 'Book', disabled: st === 'closed', onclick: function () { openBook(u); } }),
        S.admin ? el('button', { class: 'btn', type: 'button', text: 'Edit', onclick: function () { openEdit(u); } }) : null,
        S.admin ? (u.status === 'closed' ? el('button', { class: 'btn', type: 'button', text: 'Reopen', onclick: function () { reopen(u); } }) : el('button', { class: 'btn danger', type: 'button', text: 'Close', onclick: function () { openClose(u); } })) : null);
      box.append(el('article', { class: 'card' + (st === 'closed' ? ' is-closed' : '') }, media,
        el('div', { class: 'cbody' }, el('h3', { text: u.name }), specs,
          u.price != null ? el('div', { class: 'price' }, money(u.price), el('small', { text: ' / ' + periodOf(u) })) : el('div', { class: 'price' }, el('small', { text: 'Price on request' })),
          u.desc ? el('p', { class: 'desc', text: u.desc }) : null,
          st === 'closed' && u.closedNote ? el('p', { class: 'note', text: u.closedNote }) : null,
          acts)));
    });
  }

  /* ---------- Calendar tab ---------- */
  function renderBoard() {
    var box = $('#board'); box.replaceChildren();
    var units = sortedUnits(), DAYS = 28;
    if (!units.length) { box.append(el('div', { class: 'empty', style: 'border:0' }, el('p', { text: S.loaded ? 'No camps or slips to show yet.' : 'Loading' }))); return; }
    var days = []; for (var i = 0; i < DAYS; i++) days.push(addDays(S.calStart, i));
    $('#calTitle').textContent = fmtD(days[0]) + ' to ' + fmtD(days[DAYS - 1]);
    $('#calPrev').disabled = S.calStart <= today;
    var head = el('tr', {}, el('th', { class: 'rowh', scope: 'col', text: 'Spot' }));
    days.forEach(function (d) {
      var p = parse(d);
      head.append(el('th', { scope: 'col', class: p.getDate() === 1 ? 'mo' : '' }, p.toLocaleDateString('en-US', { weekday: 'narrow' }), el('b', { text: p.getDate() })));
    });
    var body = el('tbody');
    units.forEach(function (u) {
      var bs = bookingsFor(u.id);
      var tr = el('tr', {}, el('th', { class: 'rowh', scope: 'row' }, u.name, el('small', { text: u.type === 'slip' ? (u.lengthFt ? u.lengthFt + ' ft slip' : 'Boat slip') : 'Camp' })));
      days.forEach(function (d) {
        var past = d < today, hit = bs.find(function (b) { return b.start <= d && d < b.end; });
        var cls = 'cell', lab, click = null;
        if (past) { cls += ' past'; lab = fmtDW(d) + ', past'; }
        else if (u.status === 'closed') { cls += ' closed'; lab = fmtDW(d) + ', closed'; }
        else if (hit) { cls += ' booked'; lab = fmtDW(d) + ', booked' + (S.admin && hit.guest ? ' by ' + hit.guest + (hit.kind === 'block' ? ' (blocked)' : '') : ''); }
        else { lab = fmtDW(d) + ', free. Book ' + u.name; click = function () { openBook(u, d); }; }
        tr.append(el('td', {}, el('button', { class: cls, type: 'button', title: lab, 'aria-label': lab, disabled: !click, onclick: click })));
      });
      body.append(tr);
    });
    box.append(el('table', {}, el('thead', {}, head), body));
  }

  /* ---------- Manage tab ---------- */
  var pendingCancel = null, pendingDelete = null;
  function renderManage() {
    if (!S.admin) return;
    var nameIn = $('#setName'), polIn = $('#setPolicy');
    if (!S.settingsDirty) { nameIn.value = S.settings.name || ''; polIn.value = S.settings.policy || ''; }

    var ul = $('#unitList'); ul.replaceChildren();
    var units = sortedUnits();
    if (!units.length) ul.append(el('p', { class: 'desc', text: 'No camps or slips yet. Use Add camp or slip.' }));
    units.forEach(function (u) {
      var th = el('div', { class: 'thumb' });
      if (u.photoId) th.append(el('img', { src: photoUrl(u.photoId), alt: '' })); else th.append(svgNode(WAVES_S));
      var up = bookingsFor(u.id).length;
      var sub = typeLabel(u) + (u.type === 'slip' && u.lengthFt ? ' · ' + u.lengthFt + ' ft' : '') + (u.type === 'camp' && u.sleeps ? ' · sleeps ' + u.sleeps : '') + ' · ' + (u.price != null ? money(u.price) + '/' + periodOf(u) : 'no price');
      var delBtn = pendingDelete === u.id
        ? el('button', { class: 'btn small danger', type: 'button', text: 'Confirm delete', onclick: async function () {
            pendingDelete = null;
            try { await api('/admin/unit/' + u.id, { method: 'DELETE' }); toast('Deleted ' + u.name); } catch (e) { toast(e.message); }
            refresh();
          } })
        : el('button', { class: 'btn small', type: 'button', text: 'Delete', onclick: function () {
            if (up) { toast('Cancel its upcoming bookings first'); return; }
            pendingDelete = u.id; renderManage();
          } });
      ul.append(el('div', { class: 'row' }, th,
        el('div', { class: 't' }, el('strong', {}, u.name, ' ', u.status === 'closed' ? el('span', { class: 'chip closed', text: 'Closed' }) : null), el('span', { text: sub }), u.status === 'closed' && u.closedNote ? el('span', { text: ' · ' + u.closedNote }) : null),
        el('div', { class: 'acts' },
          el('button', { class: 'btn small', type: 'button', text: 'Edit', onclick: function () { openEdit(u); } }),
          u.status === 'closed' ? el('button', { class: 'btn small', type: 'button', text: 'Reopen', onclick: function () { reopen(u); } }) : el('button', { class: 'btn small danger', type: 'button', text: 'Close', onclick: function () { openClose(u); } }),
          delBtn)));
    });

    var bl = $('#bookList'); bl.replaceChildren();
    var bs = S.bookings.slice().sort(function (a, b) { return a.start < b.start ? -1 : a.start > b.start ? 1 : 0; });
    if (!bs.length) bl.append(el('p', { class: 'desc', text: 'No upcoming bookings.' }));
    bs.forEach(function (b) {
      var u = S.units.find(function (x) { return x.id === b.unitId; }), n = nightsBetween(b.start, b.end);
      var external = b.kind === 'external', clash = S.conflicts.indexOf(b.id) >= 0;
      var btn = external ? el('span', { class: 'status', text: 'Managed by Airbnb sync' }) : pendingCancel === b.id
        ? el('button', { class: 'btn small danger', type: 'button', text: 'Confirm cancel', onclick: async function () {
            pendingCancel = null;
            try { await api('/admin/booking/' + b.id, { method: 'DELETE' }); toast('Booking cancelled'); } catch (e) { toast(e.message); }
            refresh();
          } })
        : el('button', { class: 'btn small', type: 'button', text: 'Cancel booking', onclick: function () { pendingCancel = b.id; renderManage(); } });
      bl.append(el('div', { class: 'row brow' },
        el('div', { class: 't' }, el('strong', {}, (u ? u.name : 'Removed spot'), ' ', b.kind === 'block' ? el('span', { class: 'chip closed', text: 'Blocked' }) : null, external ? el('span', { class: 'chip plain', text: 'Airbnb' }) : null, clash ? el('span', { class: 'chip booked', text: 'Overlaps Airbnb' }) : null),
          el('span', { text: fmtDW(b.start) + ' to ' + fmtDW(b.end) + ' · ' + n + (n === 1 ? ' night' : ' nights') }),
          el('span', { text: ' · ' + (b.guest || 'No name') + (b.contact ? ' · ' + b.contact : '') + (b.boatFt ? ' · ' + b.boatFt + ' ft boat' : '') + (b.note ? ' · ' + b.note : '') })),
        el('div', { class: 'acts' }, btn)));
    });
  }

  /* ---------- Airbnb calendar sync (Manage tab) ---------- */
  async function loadIcal() {
    try { S.ical = await api('/admin/ical'); renderSync(); } catch (e) { /* shown again on the next refresh */ }
  }
  function copyText(text, input) {
    var done = function () { toast('Copied'); };
    var fallback = function () { input.focus(); input.select(); toast('Press copy on your keyboard to copy the selected link'); };
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(done, fallback); else fallback();
  }
  function statusLine(st) {
    if (!st) return el('p', { class: 'status', text: 'Not connected yet.' });
    var when = new Date(st.at).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
    return st.ok
      ? el('p', { class: 'status', text: 'Last synced ' + when + ' · ' + st.count + (st.count === 1 ? ' reservation' : ' reservations') + ' blocked here' })
      : el('p', { class: 'status bad', text: 'Last try ' + when + ' failed: ' + st.error });
  }
  function renderSync() {
    var box = $('#syncList'); if (!box) return;
    box.replaceChildren();
    if (!S.admin || !S.ical) return;
    var units = sortedUnits();
    if (!units.length) { box.append(el('p', { class: 'desc', text: 'Add a camp or slip first.' })); return; }
    units.forEach(function (u) {
      var feed = location.origin + '/api/calendar.ics?unit=' + encodeURIComponent(u.id) + '&key=' + encodeURIComponent(S.ical.key);
      var feedIn = el('input', { id: 'feed-' + u.id, type: 'text', readonly: true, value: feed, 'aria-label': 'Calendar link for ' + u.name });
      var inIn = el('input', { id: 'ical-' + u.id, type: 'text', value: (S.ical.urls || {})[u.id] || '', placeholder: 'Paste the link from Airbnb', 'aria-label': 'Airbnb calendar link for ' + u.name, autocomplete: 'off' });
      var save = el('button', { class: 'btn small primary', type: 'button', text: 'Save', onclick: async function () {
        save.disabled = true;
        try { S.ical = await api('/admin/ical', { method: 'PUT', body: { unitId: u.id, url: inIn.value.trim() } }); toast(inIn.value.trim() ? 'Connected and synced' : 'Disconnected'); await refresh(); }
        catch (e) { toast(e.message); }
        save.disabled = false; renderSync();
      } });
      box.append(el('div', { class: 'synccard' },
        el('h3', { text: u.name }),
        el('span', { class: 'lab', text: 'Give this link to Airbnb' }),
        el('div', { class: 'copyrow' }, feedIn, el('button', { class: 'btn small', type: 'button', text: 'Copy', onclick: function () { copyText(feed, feedIn); } })),
        el('span', { class: 'lab', text: 'Airbnb link for this spot' }),
        el('div', { class: 'copyrow' }, inIn, save),
        statusLine((S.ical.status || {})[u.id])));
    });
  }
  $('#syncNow').addEventListener('click', async function () {
    var b = this; b.disabled = true; b.textContent = 'Syncing';
    try { S.ical = await api('/admin/ical/sync', { method: 'POST' }); toast('Sync finished'); await refresh(); }
    catch (e) { toast(e.message); }
    b.disabled = false; b.textContent = 'Sync now'; renderSync();
  });

  /* ---------- tabs, filters, chrome ---------- */
  function setTab(t) {
    if (t === 'manage' && !S.admin) t = 'book';
    S.tab = t;
    ['book', 'cal', 'manage'].forEach(function (k) {
      $('#p-' + k).hidden = k !== t; $('#tab-' + k).setAttribute('aria-selected', String(k === t));
    });
  }
  function renderChrome() {
    $('#campName').textContent = S.settings.name || 'Camp Booking';
    document.title = (S.settings.name || 'Camp') + ' Booking';
    $('#policyText').textContent = S.settings.policy || DEFAULT_POLICY;
    $('#role').textContent = S.admin ? 'Admin view' : 'Book a stay';
    $('#tab-manage').hidden = !S.admin;
    $('#adminBtn').textContent = S.admin ? 'Lock admin' : 'Admin sign in';
    var b = $('#banner');
    if (S.loadErr && S.loaded) { b.hidden = false; b.className = 'banner'; b.textContent = 'Could not load the latest availability. Retrying.'; }
    else if (S.admin && S.conflicts.length) { b.hidden = false; b.className = 'banner warn'; b.textContent = S.conflicts.length + (S.conflicts.length === 1 ? ' booking overlaps' : ' bookings overlap') + ' a reservation from Airbnb. Check the upcoming bookings under Manage and contact the guest.'; }
    else if (S.admin && S.defaultPw) { b.hidden = false; b.className = 'banner warn'; b.textContent = 'You are still using the starting passcode. Change it under Manage, Admin passcode.'; }
    else b.hidden = true;
    if (!S.admin && S.tab === 'manage') setTab('book');
  }
  function renderAll() {
    renderChrome(); renderCards(); renderBoard(); renderManage();
    var active = document.activeElement;
    if (!(active && active.id && active.id.indexOf('ical-') === 0)) renderSync();   // do not wipe a link being pasted
    if (modalRefresh) modalRefresh();
  }

  document.querySelectorAll('.tab').forEach(function (t) { t.addEventListener('click', function () { setTab(t.dataset.tab); }); });
  document.querySelectorAll('#typeSeg button').forEach(function (b) {
    b.addEventListener('click', function () {
      S.type = b.dataset.type;
      document.querySelectorAll('#typeSeg button').forEach(function (x) { x.setAttribute('aria-pressed', String(x === b)); });
      renderCards();
    });
  });
  $('#fStart').min = today; $('#fEnd').min = today;
  $('#fStart').addEventListener('input', function () {
    S.start = this.value;
    if (S.start && (!S.end || S.end <= S.start)) { S.end = addDays(S.start, 1); $('#fEnd').value = S.end; }
    renderCards();
  });
  $('#fEnd').addEventListener('input', function () { S.end = this.value; renderCards(); });
  $('#fBoat').addEventListener('input', function () { S.boat = this.value; renderCards(); });
  $('#fClear').addEventListener('click', function () {
    S.start = S.end = S.boat = ''; S.type = 'all';
    $('#fStart').value = $('#fEnd').value = $('#fBoat').value = '';
    document.querySelectorAll('#typeSeg button').forEach(function (x) { x.setAttribute('aria-pressed', String(x.dataset.type === 'all')); });
    renderCards();
  });
  $('#calPrev').addEventListener('click', function () { var n = addDays(S.calStart, -7); S.calStart = n < today ? today : n; renderBoard(); });
  $('#calNext').addEventListener('click', function () { S.calStart = addDays(S.calStart, 7); renderBoard(); });
  $('#calToday').addEventListener('click', function () { S.calStart = today; renderBoard(); });
  $('#addUnit').addEventListener('click', function () { openEdit(null); });

  /* ---------- admin sign in / settings / passcode ---------- */
  function openPasscode() {
    var inp = el('input', { id: 'pc', type: 'password', autocomplete: 'current-password', required: true });
    var msg = el('p', { class: 'note', role: 'status' });
    var go = el('button', { class: 'btn primary', type: 'submit', text: 'Unlock' });
    var form = el('form', { style: 'display:grid;gap:14px', onsubmit: async function (ev) {
      ev.preventDefault(); go.disabled = true; msg.textContent = '';
      try {
        var r = await api('/login', { method: 'POST', body: { passcode: inp.value } });
        saveToken(r.token); closeModal(); toast('Admin unlocked'); S.last = ''; await refresh();
      } catch (e) {
        msg.textContent = e.status ? e.message : 'Could not reach the server. Try again.';
        go.disabled = false; inp.select();
      }
    } },
      el('div', { class: 'field' }, el('label', { for: 'pc', text: 'Passcode' }), inp),
      msg,
      el('div', { class: 'dactions' }, el('button', { class: 'btn', type: 'button', text: 'Cancel', onclick: closeModal }), go));
    openModal('Admin sign in', form);
  }
  $('#adminBtn').addEventListener('click', function () {
    if (S.admin) { saveToken(null); S.admin = false; S.last = ''; setTab('book'); closeModal(); refresh().then(renderAll); renderAll(); }
    else openPasscode();
  });

  ['#setName', '#setPolicy'].forEach(function (s) { $(s).addEventListener('input', function () { S.settingsDirty = true; }); });
  $('#saveSettings').addEventListener('click', async function () {
    try {
      await api('/admin/settings', { method: 'PUT', body: { name: $('#setName').value.trim(), policy: $('#setPolicy').value.trim() } });
      S.settingsDirty = false; toast('Saved'); await refresh();
    } catch (e) { toast(e.message); }
  });

  $('#pwForm').addEventListener('submit', async function (ev) {
    ev.preventDefault();
    var form = this, msg = $('#pwMsg');
    var old = $('#pwOld').value, nw = $('#pwNew').value.trim(), n2 = $('#pwNew2').value.trim();
    msg.textContent = '';
    if (nw.length < 6) { msg.textContent = 'Use at least 6 characters.'; return; }
    if (nw.toLowerCase() !== n2.toLowerCase()) { msg.textContent = 'The new passcodes do not match.'; return; }
    try {
      var r = await api('/admin/passcode', { method: 'POST', body: { old: old, new: nw } });
      saveToken(r.token); form.reset(); toast('Passcode changed'); S.last = ''; refresh();
    } catch (e) { msg.textContent = e.status ? e.message : 'Could not change it. Try again.'; }
  });

  /* ---------- start ---------- */
  renderAll();
  refresh();
  setInterval(function () { if (!document.hidden && !document.querySelector('.dialog')) refresh(); }, 10000);
  document.addEventListener('visibilitychange', function () { if (!document.hidden) refresh(); });
})();
